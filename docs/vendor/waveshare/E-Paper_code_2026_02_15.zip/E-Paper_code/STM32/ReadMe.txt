中文：
简单使用：
打开工程后点击编译栏的下拉框，选择对应屏幕的目标，然后点击编译。

English：
Easy to use:
After opening the project, click the drop-down box in the Compile bar, select the target of the corresponding screen, and then click Compile.